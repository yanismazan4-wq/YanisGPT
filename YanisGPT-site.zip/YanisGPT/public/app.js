const $ = (s) => document.querySelector(s);
const messagesEl = $("#messages");
const welcome = $("#welcome");
const input = $("#input");
const composer = $("#composer");
const sendBtn = $("#sendBtn");
const typing = $("#typing");
const chatList = $("#chatList");
const toast = $("#toast");

let chats = JSON.parse(localStorage.getItem("yanisgpt_chats") || "[]");
let current = null;
let busy = false;

function save() {
  localStorage.setItem("yanisgpt_chats", JSON.stringify(chats));
}

function id() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;" }[c]));
}

function renderList() {
  chatList.innerHTML = chats.slice().reverse().map(c => `
    <button class="chat-row ${c.id === current ? "active" : ""}" data-id="${c.id}">
      <span class="dot">▱</span><span class="chat-title">${escapeHtml(c.title || "Nouvelle discussion")}</span>
    </button>
  `).join("");
  chatList.querySelectorAll(".chat-row").forEach(b => b.onclick = () => openChat(b.dataset.id));
}

function renderMessages() {
  messagesEl.innerHTML = "";
  const chat = chats.find(c => c.id === current);
  if (!chat || chat.messages.length === 0) {
    welcome.style.display = "";
    return;
  }
  welcome.style.display = "none";
  chat.messages.forEach(m => {
    const row = document.createElement("div");
    row.className = `msg ${m.role}`;
    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = m.content;
    row.appendChild(bubble);
    messagesEl.appendChild(row);
  });
  messagesEl.scrollTop = messagesEl.scrollHeight;
  window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
}

function newChat() {
  const c = { id: id(), title: "Nouvelle discussion", messages: [] };
  chats.push(c);
  current = c.id;
  save(); renderList(); renderMessages();
  $("#sidebar")?.classList.remove("open");
  input.focus();
}

function openChat(chatId) {
  current = chatId;
  renderList(); renderMessages();
  $("#sidebar")?.classList.remove("open");
}

function ensureChat() {
  if (!current || !chats.find(c => c.id === current)) newChat();
  return chats.find(c => c.id === current);
}

function showToast(text) {
  toast.textContent = text;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2600);
}

async function sendMessage(text) {
  text = text.trim();
  if (!text || busy) return;

  const chat = ensureChat();
  chat.messages.push({ role: "user", content: text });
  if (chat.title === "Nouvelle discussion") chat.title = text.slice(0, 34);
  save(); renderList(); renderMessages();

  input.value = "";
  input.style.height = "auto";
  busy = true; sendBtn.disabled = true; typing.style.display = "block";

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: chat.messages })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Erreur inconnue");
    chat.messages.push({ role: "assistant", content: data.text });
    save(); renderMessages();
  } catch (e) {
    chat.messages.push({ role: "assistant", content: "Désolé 😕\n\n" + e.message });
    save(); renderMessages();
  } finally {
    busy = false; sendBtn.disabled = false; typing.style.display = "none";
    input.focus();
  }
}

composer.addEventListener("submit", e => {
  e.preventDefault();
  sendMessage(input.value);
});

input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 130) + "px";
});

input.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    composer.requestSubmit();
  }
});

document.querySelectorAll(".suggestions button").forEach(b => {
  b.addEventListener("click", () => sendMessage(b.dataset.prompt));
});

$("#newChat").onclick = newChat;
$("#menuBtn").onclick = () => $("#sidebar").classList.toggle("open");

function toggleTheme() {
  const light = document.body.dataset.theme === "light";
  if (light) {
    delete document.body.dataset.theme;
    document.documentElement.style.setProperty("--bg", "#030713");
    document.documentElement.style.setProperty("--text", "#f5f7fb");
  } else {
    document.body.dataset.theme = "light";
    document.documentElement.style.setProperty("--bg", "#f4f6fb");
    document.documentElement.style.setProperty("--text", "#101522");
  }
}
$("#themeBtn").onclick = toggleTheme;
$("#themeTop").onclick = toggleTheme;

$("#clearBtn").onclick = () => {
  if (!confirm("Effacer toutes les discussions sur cet appareil ?")) return;
  chats = []; current = null; save(); renderList(); renderMessages();
};

if (chats.length) {
  current = chats[chats.length - 1].id;
}
renderList();
renderMessages();